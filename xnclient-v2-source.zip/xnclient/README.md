# xnclient 2.0 — Fabric visual client

**Target:** Minecraft Java Edition 1.21.4 · Fabric · Java 21  
**UI:** Purple theme · compact layout · touch-friendly hit areas  
**Launcher target:** MojoLauncher (Android compatibility is not yet verified)

## What is included

- Fabric-клиент `xnclient` (Minecraft 1.21.4, Java 21), фиолетовая тема.
- ClickGUI: **Right Shift** или кнопка `xnclient` в меню паузы (для телефона). Тап по строке — вкл/выкл, перетаскивание — скролл.
- Рабочие HUD-модули: FPS Counter, Coordinates, Keystrokes, Armor HUD, Inventory Preview, Item Status.
- Config: HUD Background, GUI Blur (ванильный блюр меню — зависит от настройки «Menu Background Blur» в игре).
- Настройки сохраняются в `config/xnclient.json`.

## Build

1. 64-bit JDK 21.
2. Открыть папку как Gradle-проект в IntelliJ IDEA, дождаться загрузки Loom/Minecraft/Fabric API.
3. `gradle build` → `build/libs/xnclient-1.0.0-dev.jar`.

Компиляция здесь НЕ проверялась (нет сети/Gradle). Если сборка упадёт — пришли текст ошибки, поправлю.

## MojoLauncher / Android

Это Java-мод, а не APK. Нужны Minecraft 1.21.4 + Fabric Loader + Fabric API в MojoLauncher. Работоспособность на конкретном телефоне нужно проверять тестом.

## Дальше

- [ ] Тест сборки и запуска
- [ ] Перетаскиваемые HUD-виджеты
- [ ] Бинды клавиш на модули
