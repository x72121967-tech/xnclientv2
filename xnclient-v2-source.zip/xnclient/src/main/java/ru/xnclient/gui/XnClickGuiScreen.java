package ru.xnclient.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import ru.xnclient.module.Category;
import ru.xnclient.module.Module;
import ru.xnclient.module.ModuleManager;

import java.util.List;

/** Компактный сенсорный ClickGUI: тап по строке — вкл/выкл, перетаскивание — скролл. */
public final class XnClickGuiScreen extends Screen {
    private static final int BG = 0xF20B0A10;
    private static final int PANEL = 0xF2161420;
    private static final int PANEL_ALT = 0xF21D1929;
    private static final int PURPLE = 0xFF9B5CFF;
    private static final int TEXT = 0xFFF4F0FA;
    private static final int MUTED = 0xFFAAA2B8;
    private static final int ROW_H = 28;
    private static final int ROW_STEP = 33;

    private Category selected = Category.VISUAL;
    private int panelX, panelY, panelW, panelH;
    private int contentX, listTop, listBottom;
    private double scroll;

    // тап vs. перетаскивание
    private Module pressedModule;
    private boolean dragged;

    public XnClickGuiScreen() {
        super(Text.literal("xnclient"));
    }

    @Override
    protected void init() {
        panelW = Math.min(430, Math.max(260, this.width - 20));
        panelH = Math.min(270, Math.max(190, this.height - 20));
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;
        contentX = panelX + 118;
        listTop = panelY + 48;
        listBottom = panelY + panelH - 24;
    }

    /** Фон: ванильный блюр (если включён GUI Blur) или просто затемнение. */
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        if (ModuleManager.GUI_BLUR.isEnabled()) {
            super.renderBackground(context, mouseX, mouseY, delta);
        } else {
            context.fill(0, 0, this.width, this.height, 0x99000000);
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, BG);
        context.fill(panelX, panelY, panelX + panelW, panelY + 2, PURPLE);
        context.fill(panelX + 1, panelY + 1, panelX + 111, panelY + panelH - 1, PANEL);
        context.fill(panelX + 111, panelY + 1, panelX + 112, panelY + panelH - 1, 0xFF342B43);

        context.drawText(this.textRenderer, Text.literal("xnclient"), panelX + 12, panelY + 12, TEXT, false);
        context.drawText(this.textRenderer, Text.literal("2.0  •  PURPLE"), panelX + 12, panelY + 27, MUTED, false);

        // вкладки
        int tabY = panelY + 46;
        for (Category c : Category.values()) {
            boolean sel = c == selected;
            if (sel) {
                context.fill(panelX + 7, tabY, panelX + 105, tabY + 25, 0xFF342447);
                context.fill(panelX + 7, tabY, panelX + 10, tabY + 25, PURPLE);
            }
            context.drawText(this.textRenderer, Text.literal(c.title), panelX + 17, tabY + 8, sel ? TEXT : MUTED, false);
            tabY += 29;
        }

        // заголовок страницы
        context.drawText(this.textRenderer, Text.literal(selected.title), contentX, panelY + 15, TEXT, false);
        context.drawText(this.textRenderer, Text.literal("Tap to toggle  •  drag to scroll"), contentX, panelY + 29, MUTED, false);
        context.fill(contentX, panelY + 42, panelX + panelW - 12, panelY + 43, 0xFF342B43);

        List<Module> modules = ModuleManager.byCategory(selected);
        if (modules.isEmpty()) {
            context.drawText(this.textRenderer, Text.literal("No modules on this page yet."), contentX, listTop + 4, MUTED, false);
        } else {
            clampScroll(modules.size());
            context.enableScissor(contentX, listTop, panelX + panelW - 12, listBottom);
            int y = listTop - (int) scroll;
            for (Module m : modules) {
                if (y + ROW_H >= listTop && y <= listBottom) drawRow(context, m, y);
                y += ROW_STEP;
            }
            context.disableScissor();
        }

        context.drawText(this.textRenderer, Text.literal("RIGHT SHIFT / ESC  •  CLOSE"),
                contentX, panelY + panelH - 17, MUTED, false);
        super.render(context, mouseX, mouseY, delta);
    }

    private void drawRow(DrawContext context, Module m, int y) {
        int right = panelX + panelW - 12;
        context.fill(contentX, y, right, y + ROW_H, PANEL_ALT);
        context.drawText(this.textRenderer, Text.literal(m.name), contentX + 8, y + 5, TEXT, false);
        context.drawText(this.textRenderer, Text.literal(m.description), contentX + 8, y + 16, MUTED, false);
        // переключатель
        int sw = right - 34;
        context.fill(sw, y + 8, sw + 24, y + 20, m.isEnabled() ? PURPLE : 0xFF51465F);
        int knob = m.isEnabled() ? sw + 14 : sw + 2;
        context.fill(knob, y + 10, knob + 8, y + 18, TEXT);
    }

    private void clampScroll(int count) {
        double max = Math.max(0, count * ROW_STEP - (listBottom - listTop));
        scroll = Math.max(0, Math.min(max, scroll));
    }

    private Module moduleAt(double mx, double my) {
        if (mx < contentX || mx > panelX + panelW - 12 || my < listTop || my > listBottom) return null;
        List<Module> modules = ModuleManager.byCategory(selected);
        int index = (int) ((my - listTop + scroll) / ROW_STEP);
        double within = (my - listTop + scroll) - index * ROW_STEP;
        if (index < 0 || index >= modules.size() || within > ROW_H) return null;
        return modules.get(index);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int tabTop = panelY + 46;
            for (Category c : Category.values()) {
                if (mouseX >= panelX + 7 && mouseX <= panelX + 105 && mouseY >= tabTop && mouseY <= tabTop + 25) {
                    selected = c;
                    scroll = 0;
                    return true;
                }
                tabTop += 29;
            }
            pressedModule = moduleAt(mouseX, mouseY);
            dragged = false;
            if (pressedModule != null) return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (button == 0 && mouseX >= contentX) {
            if (Math.abs(deltaY) > 0.5) dragged = true;
            scroll -= deltaY;
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0 && pressedModule != null) {
            Module m = pressedModule;
            pressedModule = null;
            if (!dragged && moduleAt(mouseX, mouseY) == m) {
                m.toggle();
                ModuleManager.save();
            }
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll -= verticalAmount * 20;
        return true;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
