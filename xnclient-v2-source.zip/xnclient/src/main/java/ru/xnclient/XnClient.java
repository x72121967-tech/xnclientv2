package ru.xnclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.xnclient.gui.XnClickGuiScreen;
import ru.xnclient.hud.XnHud;
import ru.xnclient.module.ModuleManager;

/** Точка входа xnclient. */
public final class XnClient implements ClientModInitializer {
    public static final String MOD_ID = "xnclient";
    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        ModuleManager.load();
        XnHud.register();

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xnclient.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.xnclient.main"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new XnClickGuiScreen());
                } else if (client.currentScreen instanceof XnClickGuiScreen) {
                    client.setScreen(null);
                }
            }
        });

        // Для телефона: кнопка "xnclient" в меню паузы (Esc / кнопка паузы),
        // чтобы открыть ClickGUI тапом, без клавиатуры.
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(
                        ButtonWidget.builder(Text.literal("xnclient"),
                                        b -> client.setScreen(new XnClickGuiScreen()))
                                .dimensions(6, 6, 80, 20)
                                .build());
            }
        });
    }
}
