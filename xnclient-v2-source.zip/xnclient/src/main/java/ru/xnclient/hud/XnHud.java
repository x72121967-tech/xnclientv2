package ru.xnclient.hud;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import ru.xnclient.gui.XnClickGuiScreen;
import ru.xnclient.module.ModuleManager;

import java.util.ArrayList;
import java.util.List;

/** HUD xnclient: фиолетовая компактная панель слева + броня справа. */
public final class XnHud {
    private static final int PURPLE = 0xFF9B5CFF;
    private static final int TEXT = 0xFFF4F0FA;
    private static final int BG = 0x99100E18;
    private static final int KEY_OFF = 0x99201C2C;
    private static final int KEY_ON = 0xCC9B5CFF;
    private static final int PAD = 4;
    private static final int LEFT = 4;
    private static final int TOP = 4;

    private XnHud() {}

    public static void register() {
        HudRenderCallback.EVENT.register(XnHud::render);
    }

    private static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        PlayerEntity player = mc.player;
        if (player == null || mc.options.hudHidden || mc.currentScreen instanceof XnClickGuiScreen) return;
        TextRenderer font = mc.textRenderer;

        int y = TOP;

        // --- текстовые строки ---
        List<String> lines = new ArrayList<>();
        if (ModuleManager.FPS.isEnabled()) lines.add(mc.getCurrentFps() + " FPS");
        if (ModuleManager.COORDS.isEnabled()) {
            lines.add("XYZ " + player.getBlockX() + " " + player.getBlockY() + " " + player.getBlockZ());
        }
        if (ModuleManager.ITEM_STATUS.isEnabled()) {
            ItemStack held = player.getMainHandStack();
            if (!held.isEmpty()) {
                String s = held.getName().getString();
                if (held.getMaxDamage() > 0) {
                    s += "  " + (held.getMaxDamage() - held.getDamage()) + "/" + held.getMaxDamage();
                }
                lines.add(s);
            }
        }
        if (!lines.isEmpty()) {
            int w = 0;
            for (String l : lines) w = Math.max(w, font.getWidth(l));
            int h = lines.size() * 11 + PAD * 2 - 2;
            int boxW = w + PAD * 2 + 3;
            if (ModuleManager.HUD_BG.isEnabled()) ctx.fill(LEFT, y, LEFT + boxW, y + h, BG);
            ctx.fill(LEFT, y, LEFT + 2, y + h, PURPLE);
            int ty = y + PAD;
            for (String l : lines) {
                ctx.drawText(font, l, LEFT + PAD + 3, ty, TEXT, true);
                ty += 11;
            }
            y += h + 4;
        }

        // --- Keystrokes ---
        if (ModuleManager.KEYSTROKES.isEnabled()) {
            int s = 18;
            key(ctx, font, "W", LEFT + s + 2, y, s, mc.options.forwardKey);
            key(ctx, font, "A", LEFT, y + s + 2, s, mc.options.leftKey);
            key(ctx, font, "S", LEFT + s + 2, y + s + 2, s, mc.options.backKey);
            key(ctx, font, "D", LEFT + (s + 2) * 2, y + s + 2, s, mc.options.rightKey);
            key(ctx, font, "JUMP", LEFT, y + (s + 2) * 2, s * 3 + 4, mc.options.jumpKey);
            y += (s + 2) * 3 + 2;
        }

        // --- Inventory preview (3 ряда по 9) ---
        if (ModuleManager.INV_PREVIEW.isEnabled()) {
            int cell = 16;
            if (ModuleManager.HUD_BG.isEnabled()) {
                ctx.fill(LEFT, y, LEFT + cell * 9 + 4, y + cell * 3 + 4, BG);
            }
            ctx.fill(LEFT, y, LEFT + 2, y + cell * 3 + 4, PURPLE);
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 9; col++) {
                    ItemStack st = player.getInventory().getStack(9 + row * 9 + col);
                    if (st.isEmpty()) continue;
                    int ix = LEFT + 2 + col * cell;
                    int iy = y + 2 + row * cell;
                    ctx.drawItem(st, ix, iy);
                    ctx.drawStackOverlay(font, st, ix, iy);
                }
            }
        }

        // --- Armor HUD (справа) ---
        if (ModuleManager.ARMOR.isEnabled()) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            int ax = mc.getWindow().getScaledWidth() - 22;
            int ay = TOP;
            for (EquipmentSlot slot : slots) {
                ItemStack st = player.getEquippedStack(slot);
                if (st.isEmpty()) continue;
                if (ModuleManager.HUD_BG.isEnabled()) ctx.fill(ax - 2, ay - 1, ax + 18, ay + 17, BG);
                ctx.drawItem(st, ax, ay);
                ctx.drawStackOverlay(font, st, ax, ay);
                ay += 19;
            }
        }
    }

    private static void key(DrawContext ctx, TextRenderer font, String label, int x, int y, int w, KeyBinding kb) {
        ctx.fill(x, y, x + w, y + 18, kb.isPressed() ? KEY_ON : KEY_OFF);
        ctx.drawText(font, label, x + (w - font.getWidth(label)) / 2, y + 5, TEXT, false);
    }
}
