package ru.xnclient.module;

public enum Category {
    COMBAT("Combat"), MOVEMENT("Movement"), PLAYER("Player"),
    VISUAL("Visual"), MISC("Misc"), CONFIG("Config");

    public final String title;

    Category(String title) {
        this.title = title;
    }
}
