package ru.xnclient.module;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Список модулей + сохранение включённых/выключенных в config/xnclient.json. */
public final class ModuleManager {
    private static final List<Module> ALL = new ArrayList<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // Visual
    public static final Module FPS = add(new Module("FPS Counter", "FPS в углу экрана", Category.VISUAL, true));
    public static final Module COORDS = add(new Module("Coordinates", "Координаты XYZ", Category.VISUAL, true));
    public static final Module KEYSTROKES = add(new Module("Keystrokes", "WASD и прыжок на экране", Category.VISUAL, true));
    public static final Module ARMOR = add(new Module("Armor HUD", "Броня и прочность справа", Category.VISUAL, true));
    // Player
    public static final Module INV_PREVIEW = add(new Module("Inventory Preview", "Содержимое инвентаря на HUD", Category.PLAYER, false));
    public static final Module ITEM_STATUS = add(new Module("Item Status", "Предмет в руке и прочность", Category.PLAYER, true));
    // Config
    public static final Module HUD_BG = add(new Module("HUD Background", "Тёмная подложка под HUD", Category.CONFIG, true));
    public static final Module GUI_BLUR = add(new Module("GUI Blur", "Размытие фона за меню", Category.CONFIG, true));

    private ModuleManager() {}

    private static Module add(Module m) {
        ALL.add(m);
        return m;
    }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) {
            if (m.category == c) out.add(m);
        }
        return out;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("xnclient.json");
    }

    public static void load() {
        Path p = file();
        if (!Files.exists(p)) return;
        try {
            JsonObject root = GSON.fromJson(Files.readString(p), JsonObject.class);
            if (root == null) return;
            for (Module m : ALL) {
                if (root.has(m.name)) m.setEnabled(root.get(m.name).getAsBoolean());
            }
        } catch (Exception ignored) {
            // битый конфиг — остаются значения по умолчанию
        }
    }

    public static void save() {
        JsonObject root = new JsonObject();
        for (Module m : ALL) root.addProperty(m.name, m.isEnabled());
        try {
            Files.writeString(file(), GSON.toJson(root));
        } catch (IOException ignored) {
        }
    }
}
